export default class WitcherItem extends Item {
  chatTemplate = {
    "weapon": "systems/TheWitcherTRPG/templates/partials/chat/weapon-chat.html"
  }

  async roll() {
  }
}